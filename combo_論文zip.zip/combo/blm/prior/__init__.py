from .gauss import gauss

__all__ = ["gauss"]

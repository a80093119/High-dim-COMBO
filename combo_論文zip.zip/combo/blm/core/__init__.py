from .model import model

__all__ = ["model"]

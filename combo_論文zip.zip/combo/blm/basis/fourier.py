# -*- coding:utf-8 -*-
import numpy as np
import time

class fourier:
    ''' class for fourier basis '''
    def __init__( self, params ):
        self._check_params( params )
        self._check_len_params( params )
        self.params = params
        self.nbasis = self.params[1].shape[0]

    def get_basis( self, X, params = None ):
        ''' compute basis functions '''
        if params is None:
            params = self.params

        self._check_params( params )
        self._check_len_params( params )
        
#        temp = np.cos( np.dot( X, params[0].transpose() ) + params[1] ) * params[2]
        n = 100000
        j = int(X.shape[0]/n) + 1
        if j == 1:
            return np.cos( np.dot( X, params[0].transpose() ) + params[1] ) * params[2]
        else:
            for i in range(j):
                if i == 0:
                    temp = np.cos( np.dot( X[n*i:n*(i+1), :], params[0].transpose() ) + params[1] ) * params[2]
                    Final = np.cos( np.dot( X[n*i:n*(i+1), :], params[0].transpose() ) + params[1] ) * params[2]
                elif i == (j-1):
                    temp = np.cos( np.dot( X[n*i:(n*i+X.shape[0]%n), :], params[0].transpose() ) + params[1] ) * params[2]
                    Final = np.vstack((Final, temp))
                else:
                    temp = np.cos( np.dot( X[n*i:n*(i+1), :], params[0].transpose() ) + params[1] ) * params[2]
                    Final = np.vstack((Final, temp))
            return Final

    def set_params( self, params ):
        ''' substitute the 3-dimensional tuple <params> into the instance <params> '''
        self._check_params( params )
        self._check_len_params( params )
        self.params = params

    def show( self ):
        print ('W = ', self.params[0])
        print ('b = ', self.params[1])
        print ('alpha = ', self.params[2])

    def _check_params( self, params ):
        if not isinstance( params, tuple):
            raise ValueError( 'The variable < params > must be a tuple.' )

        if len(params) !=3:
            raise ValueError( 'The variable < params > must be 3-dimensional tuple.' )

    def _check_len_params( self, params ):
        if params[0].shape[0] != params[1].shape[0]:
            raise ValueError( 'The length of 0-axis of W must be same as the length of b.' )

        if hasattr(params[2], "__len__"):
            if len(params[2]) !=1:
                raise ValueError('The third entry of <params> must be a scalar.')
            else:
                if isinstance(params[2], str):
                    raise ValueError('The third entry of <params> must be a scalar.')

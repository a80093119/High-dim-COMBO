import numpy as np
import scipy.stats
from scipy.stats import norm
import matplotlib.pyplot as plt


def EI(predictor, training, test, fmax=None):
    fmean = predictor.get_post_fmean(training, test)
    fcov_diag = predictor.get_post_fcov(training, test, diag=True)
    fstd = np.sqrt(fcov_diag)

    if fmax is None:
        fmax = np.max(predictor.get_post_fmean(training, training))

    temp1 = (fmean - fmax)
    temp2 = temp1 / fstd
    score = temp1 * scipy.stats.norm.cdf(temp2) \
        + fstd * scipy.stats.norm.pdf(temp2)

    return score


def PI(predictor, training, test, fmax=None):
    fmean = predictor.get_post_fmean(training, test)
    fcov_diag = predictor.get_post_fcov(training, test, diag=True)
    fstd = np.sqrt(fcov_diag)

    if fmax is None:
        fmax = np.max(predictor.get_post_fmean(training, training))

    temp = (fmean - fmax)/fstd
    score = scipy.stats.norm.cdf(temp)
    return score


def TS(predictor, training, test, alpha=1):
    score = predictor.get_post_samples(training, test, alpha=alpha)

    try:
        score.shape[1]
        score[0, :]
    except:
        pass

    return score

##KG
def findA_c(sort_rm):
    c = np.zeros(len(sort_rm)+1)
    c[0] = -np.inf
    c[-1] = np.inf
    A = [0]
    for i in range(1, len(sort_rm)):
        loopdone = False
        while loopdone == False:
            j = A[-1]
            if len(A)>=2:
                k = A[-2]
            c[j+1] = (sort_rm[j,0]-sort_rm[i,0])/(sort_rm[i,1]-sort_rm[j,1])
            if len(A) == 1: 
                A.append(i)
                loopdone = True
            elif len(A) != 1 and c[j+1] <= c[k+1]:
                A.remove(A[-1])
            else:
                A.append(i)
                loopdone = True
    return A, c

def sortab(predictor, training, test, scale):
    mu_s = predictor.get_post_fmean(training, test)
    sigman = predictor.get_post_fcov(training, test, diag=False)
    sigma = sigman[:, len(training.X)]/np.sqrt(scale+sigman[len(training.X)][len(training.X)])
    sort_ = np.concatenate((mu_s.reshape(len(mu_s), 1), sigma.reshape(len(sigma), 1)), axis=1)
    sort_ = np.array(sorted(sort_, key=lambda x: (x[1], -x[0])))
    same = np.unique(sort_[:, 1], axis=0)
    index_un = []
    for i in range(len(same)):
        index_un.append(list(sort_[:,1]).index(same[i]))
    sort_rm = sort_[index_un]
    return sort_rm

def KG(predictor, training, test, scale, fmax):
    sort_rm = sortab(predictor, training, test, scale)
    A, c = findA_c(sort_rm)
    c_ = [-np.inf]
    for i in range(len(A)):
        c_.append(c[1+A[i]])
    E = 0
    for i in range(len(A)):
        E = E+sort_rm[A[i], 0]*(norm.cdf(c_[i+1])-norm.cdf(c_[i]))+sort_rm[A[i], 1]*(norm.pdf(c_[i])-norm.pdf(c_[i+1]))
    return E - fmax

